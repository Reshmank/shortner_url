<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Validator, Input, Redirect ; 
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    public function shortner_url(Request $request)
    {

          $url=$request->url;

          if(!empty($url))
          {

                 
                $check=DB::table('urls')->where('long_url',$url)->get();

                if(!empty($check))
                {


                           $response = array(
                            'status' => 'Already',
                            'long_url'=>$url,
                        );
                        return \Response::json($response); 




                }


                $random = str_random(5);

                $new=explode('.',$url);

              //  $url1=!empty($new[0])?substr($new[0],0):'';
                $url2=!empty($new[1])?substr($new[1],0,1):'';

                $shorter_url=$url2.'/'.$random;


                 $urls=array(

                     'long_url'=>$url,
                     'short_url'=>$shorter_url,

                     );


                 $result=DB::table('urls')->insert($urls);

                 if($result)
                 {


                          $response = array(
                            'status' => 'success',
                            'short_url' =>$shorter_url,
                            'long_url'=>$url,
                        );
                        return \Response::json($response); 




                 }
              


                



          }

        
        






    }

}
