/*
SQLyog Community v11.3 (64 bit)
MySQL - 5.6.17 : Database - db_urls
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_urls` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_urls`;

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`migration`,`batch`) values ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `urls` */

DROP TABLE IF EXISTS `urls`;

CREATE TABLE `urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `long_url` varchar(500) NOT NULL,
  `short_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `urls` */

insert  into `urls`(`id`,`long_url`,`short_url`,`created_at`) values (1,'www.google.com','wRup7DTmhWWODxyc','2017-05-15 18:17:06'),(2,'www.google.com','Ny5fLcSVUby46psl','2017-05-15 18:18:44'),(3,'www.google.com','uJl0zO7YoelKMPeT','2017-05-15 18:26:54'),(4,'www.google.com','ClFI3Lm2uyGkdku3','2017-05-15 18:27:49'),(5,'www.google.com','Q5icjPuiCOJtu8Ti','2017-05-15 18:30:43'),(6,'www.google.com','eMP11CEzNLQcP1Ib','2017-05-15 18:32:31'),(7,'www.costprize.com/products /1234','www.costprize.comroducts /YqjtInq0GrOVuKIu','2017-05-15 18:42:22'),(8,'www.costprize.com/products /1234','www.costprize.comroducts /usEyHiVR5Y4qM8XD','2017-05-15 18:44:26'),(9,'www.costprize.com/products/1234','stprize/lGQuPHtYUZGij5Os','2017-05-15 18:48:21'),(10,'www.costprize.com/products/1234','costprize/chp2p','2017-05-15 18:49:50'),(11,'www.costprize.com/products/1234','c/jBM8C','2017-05-15 18:51:05'),(12,'fhfg','/fBxi7','2017-05-15 18:55:46'),(13,'www.google.com','g/DSiZK','2017-05-16 19:08:46');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`password`,`remember_token`,`created_at`,`updated_at`) values (1,'Reshma N.K','reshma@mail.com','$2y$10$UGMgtpVDLV94zBYCX1nnJeTJPeW1cygNoMzQsNxw6.x7BtHimWely',NULL,'2017-05-16 11:54:59','2017-05-16 11:54:59');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
