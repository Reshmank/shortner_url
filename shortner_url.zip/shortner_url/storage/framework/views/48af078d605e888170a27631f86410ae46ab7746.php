<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Shortner Url</div>

                <div class="panel-body">

                 <?php echo Form::open(['id'=>'shorten','class'=>'form-horizontal']); ?>

                       

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Link</label>

                            <div class="col-md-6">
                         <input id="link" type="text" class="form-control" name="link" value="" placeholder="Insert your URL here ">

                              
                            </div>

                            <div class="col-md-4 shorter_url"></div>


                        </div>

                       <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">


                            <input type="submit" name="" class="btn btn-primary"  value="shorten">
                                
                            </div>
                        </div>
                   <?php echo Form::close(); ?>






                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>