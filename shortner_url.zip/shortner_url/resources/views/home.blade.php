@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Shortner Url</div>

                <div class="panel-body">

                 {!! Form::open(['id'=>'shorten','class'=>'form-horizontal'])!!}
                       

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Link</label>

                            <div class="col-md-6">
                         <input id="link" type="text" class="form-control" name="link" value="" placeholder="Insert your URL here ">

                              
                            </div>

                            <div class="col-md-4 shorter_url"></div>


                        </div>

                       <input type="hidden" name="_token" value="{{ csrf_token() }}">

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">


                            <input type="submit" name="" class="btn btn-primary"  value="shorten">
                                
                            </div>
                        </div>
                   {!! Form::close() !!}





                   
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
